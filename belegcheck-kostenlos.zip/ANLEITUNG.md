# BelegCheck (kostenlose Version): Einrichtung ohne Terminal, ca. 15 Minuten

**Kosten: 0 €.** Du brauchst zwei kostenlose Konten: **GitHub** (stellt die App online) und **Google** (Gemini liest die Bons).
Deine Belegdaten liegen **nur auf deinem iPhone**. Kein Server speichert etwas.

---

## Schritt 1: App online stellen (GitHub Pages, am Computer)

1. Konto anlegen auf https://github.com (kostenlos).
2. Oben rechts auf **+** → **New repository** klicken.
   - Repository name: `belegcheck`
   - **Public** auswählen. Nur der App-Code ist öffentlich, nicht deine Daten und nicht dein Schlüssel.
   - Auf **Create repository** klicken.
3. Auf der neuen Seite den Link **„uploading an existing file“** anklicken.
4. Die ZIP-Datei entpacken und **alle Dateien und den Ordner `icons`** ins Browserfenster ziehen.
   Danach unten auf **Commit changes** klicken.
5. Oben auf **Settings** → links auf **Pages** → unter *Branch* `main` und `/ (root)` wählen → **Save**.
6. Nach 1–2 Minuten steht oben die Adresse, z. B. **`https://DEINNAME.github.io/belegcheck/`**.

## Schritt 2: Kostenlosen Gemini-Schlüssel holen

1. https://aistudio.google.com/apikey öffnen und mit einem Google-Konto anmelden.
2. **API-Schlüssel erstellen** anklicken und den Schlüssel kopieren (beginnt z. B. mit `AQ.` oder `AIza`).
   Eine Kreditkarte ist nicht nötig. Solange du **kein Abrechnungskonto verknüpfst**, bleibt alles kostenlos.

*Optional, aber empfohlen:* In der Google Cloud Console den Schlüssel einschränken.
Dazu unter *Anwendungseinschränkungen* **Websites** wählen und `https://DEINNAME.github.io/*` eintragen.
So funktioniert der Schlüssel nur in deiner App.

## Schritt 3: Aufs iPhone holen

1. Die Adresse aus Schritt 1 in **Safari** öffnen.
2. Unten auf **Teilen** (Quadrat mit Pfeil) → **Zum Home-Bildschirm** → *Hinzufügen*.
3. Die App **vom Homescreen** starten → **Mehr** → Gemini-Schlüssel einfügen → *Speichern*.
4. Fertig. Den grünen Knopf unten drücken und den ersten Bon scannen.

> **Wichtig:** Die App immer über das **Homescreen-Symbol** öffnen, nicht in Safari.
> iOS trennt die Daten zwischen Safari und der Homescreen-App.

---

## Datensicherung (bitte monatlich)

Die Daten liegen nur auf dem iPhone. Geht das iPhone verloren oder wird die App gelöscht, sind sie ohne Sicherung weg.
So sicherst du sie: **Mehr → Sicherung erstellen → „In Dateien sichern“**, am besten in iCloud Drive.
Wiederherstellen (z. B. auf einem neuen iPhone): **Mehr → Sicherung wiederherstellen**.

## Updates einspielen

Im GitHub-Repository **Add file → Upload files** wählen, die geänderten Dateien hineinziehen und auf **Commit changes** klicken.
Danach die App auf dem iPhone einmal komplett schließen und neu öffnen.

## Probleme?

| Meldung | Lösung |
|---|---|
| „Bitte zuerst … Gemini-API-Schlüssel eintragen“ | Mehr → Schlüssel einfügen → Speichern |
| „API-Schlüssel ist ungültig“ | Schlüssel neu kopieren (ohne Leerzeichen) |
| „Kontingent ausgeschöpft“ | Das kostenlose Limit ist kurz erreicht. Später erneut versuchen, die Fotos bleiben erhalten. |
| „Modell … nicht gefunden“ | Mehr → Erweitert → aktuelles Modell eintragen (Liste: ai.google.dev/gemini-api/docs/models) |
| 403 / Zugriff verweigert | Die Einschränkung des Schlüssels passt nicht zur App-Adresse |
| Bon wird schlecht erkannt | Heller fotografieren, Bon glatt legen, lange Bons in mehreren Fotos aufnehmen |

## Aufbau (zur Orientierung)

```
index.html          Grundgerüst der App
app.js              Bildschirme, Kamera, Diagramme
local-api.js        Speichern, Auswertungen, Sparpotenzial, Export/Sicherung
db.js               lokale Datenbank auf dem iPhone (IndexedDB)
gemini.js           Bon-Erkennung (Foto → strukturierte Daten)
categories.js       Kategorien
style.css           Design (hell/dunkel)
sw.js, manifest     Homescreen-App, schneller Start
icons/              App-Symbole
```
